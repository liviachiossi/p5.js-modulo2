let cor; // definição de cor 
let posicaoHorizontal; // x
let posicaoVertical;   // y 

function setup() {
 
  createCanvas(400, 400);
 background( color(100, 0, 0)); // cor do cenário
   cor = color(random(0, 255), random(0, 255) , random(0, 255)); // definição da cor do círculo através de números aleatórios 
  posicaoHorizontal = 200; // definindo a posição x
  posicaoVertical = 200;  // definindo a posição y 
}

function draw() { // função do desenho
  
  fill(cor); // coloração do círculo
  circle(posicaoHorizontal, posicaoVertical, 50); // posição e tamanho do círculo
  
 if(mouseX < posicaoHorizontal) {
    posicaoHorizontal = posicaoHorizontal - 1; // definição da direção para a esquerda
    }
  
  if (mouseX > posicaoHorizontal) { 
     posicaoHorizontal = posicaoHorizontal + 1; // definição da direção para a direita
  }

  if (mouseY < posicaoVertical) { 
  posicaoVertical--; // definição da direção para baixo
  }

  if (mouseY > posicaoVertical) { 
  posicaoVertical++; // definiçaõ da direção para cima
  }

  if (mouseIsPressed)  { 
   cor = color(random(0, 255), random(0, 255) , random(0, 255), random(0, 100)); // definição da cor do círculo através de números aleatórios 
  }


}
